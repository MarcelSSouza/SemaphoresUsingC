#!/bin/bash

./probSemSharedMemAirLift | awk -f filter_log.awk

